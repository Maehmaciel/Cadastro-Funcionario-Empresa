/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.Dao;

import Modelo.Negocio.Cargo;
import Modelo.Negocio.Funcionario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author aluno
 */
public class CargoDao {
     Connection con;

    public CargoDao() throws ClassNotFoundException, SQLException {
        Class.forName("org.postgresql.Driver");
        con=DriverManager.getConnection("jdbc:postgresql://tuffi.db.elephantsql.com/xzqwzibj","xzqwzibj","iXHBrqE_v4jfEwablB5D9aMQRuB2SlsN");

    }
     public void sair() throws SQLException
    {
        if(con!=null)
            con.close();
    }
     
       public List<Cargo> pegaCargo() throws SQLException{
         List<Funcionario> listaFuncionario;
         List<Cargo> listaCargo;
         int total=0;
        try (PreparedStatement gen = con.prepareStatement("SELECT count(*) from cargo")) {
            ResultSet rs=gen.executeQuery();
            while(rs.next())
            {
                total=rs.getInt(1);
                System.out.println(total);
            }
            gen.close();
        }
        
        
        try (PreparedStatement gen = con.prepareStatement("SELECT * from cargo")) {
            ResultSet rs=gen.executeQuery();
            listaCargo=new ArrayList();
            Cargo c=null;
            while(rs.next())
            {
                c=new Cargo();
                c.setId(rs.getInt(1));
                c.setCargo(rs.getString(2));
                c.setSalario(rs.getInt(3));
                listaCargo.add(c);
                System.out.println("Entrei"+listaCargo.get(1).getCargo());
            }
             gen.close();
        }
        
        
        
        
        
        
       listaCargo = new ArrayList();
        for(int i=1;i!=total;i++){
             PreparedStatement ps=con.prepareStatement("SELECT f.*, c.salario,c.cargo FROM funcionario as f INNER JOIN cargo as c on f.cargo=c.id where f.cargo=?");
        ps.setInt(1, i);
        ResultSet rs=ps.executeQuery();
        listaFuncionario = new ArrayList();
            
             Funcionario f=null;
             
            while(rs.next())
            {
               f=new Funcionario();
               f.setId(rs.getInt(1));
               f.setNome(rs.getString(2));
               f.setTelefone(rs.getString(3));                 
               
               listaFuncionario.add(f);
            }
            int pos=i-1;
            listaCargo.get(pos).setFuncionario(listaFuncionario);
     
       
       ps.close();
        }return listaCargo;
         
     }
     
    /* public List<Funcionario> pegaFuncionarios() throws SQLException{
      List<Funcionario> lista;
       PreparedStatement gen = con.prepareStatement("SELECT f.nome,f.telefone, c.cargo,c.salario FROM funcionario as f INNER JOIN cargo as c on f.cargo=c.id order by f.cargo");
       ResultSet rs=gen.executeQuery();
            
            lista = new ArrayList();
            Cargo c=null;
             Funcionario f=null;
            while(rs.next())
            {
               f=new Funcionario();
                
               f.setNome(rs.getString(1));
               f.setTelefone(rs.getString(2));                 
               c=new Cargo();
               c.setCargo(rs.getString(3));
               c.setSalario(rs.getInt(4));
               f.setC(c);
               lista.add(f);
            }return lista;
            
       
        
        
     }*/
     
     public static void main(String[] args) throws ClassNotFoundException, SQLException {
        
        
             CargoDao dao=new CargoDao();
              List<Cargo> lista= dao.pegaCargo();
              for(Cargo c : lista){
                  
             System.out.println(c.getCargo());
                  for(Funcionario f : c.getFuncionario()){
                  
             System.out.println(f.getNome());
             
             
              }
             
              }
     dao.pegaCargo();
     }
         
        
    
}
